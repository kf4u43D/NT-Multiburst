# Multi Burst NT: 16 modulation scenes

Open any file in `patches/` with VCV Rack 2, Fundamental and nt_emu. Set the
engine to 48 kHz. PULSES 1 triggers both voices, 2 resets them and 3 advances
one burst. ENV MIX feeds the audio VCA. Select your driver and device in
AUDIO 2; the output volume starts at 15%.

Modulation is initially disabled. Enable it with Width CV input=4,
Interval CV input=5 and Shape CV input=6. Their bipolar LFOs run at
0.125 / 0.088 / 0.051 Hz. Clock input=None uses each scene's own timing;
Clock input=2 and Clock source=Internal + CV add the external 2.7 Hz LFO
in Absolute mode. Hand Steps waits for PULSES 3 after its first burst.

The [JSON catalogue](catalog.json) contains the 25 values per voice, shared
settings and all exported parameters. It is evaluated directly from
[performance_presets.h](source/performance_presets.h). DROID banks remain
independent. The [manifest](manifest.json) lists file checksums.

Patches store the absolute path to the exported Windows DLL. If the project
or DLL moves, regenerate them from the project directory:

```powershell
python scripts/export-preset-pack.py --library dist/nt_emu/multi_burst.dll
```

The [16-scene guide](guide.md) describes each scene and how to load it on NT.
