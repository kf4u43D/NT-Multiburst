# Multi Burst NT : 16 scènes de modulation

Ouvrir un des 16 fichiers dans `patches/` avec VCV Rack 2, Fundamental et nt_emu.
Régler le moteur à 48 kHz. PULSES 1 lance les voix, 2 les réinitialise et 3
avance d'un burst. Les deux voix passent dans ENV MIX puis le VCA audio ; choisir
le pilote et le périphérique dans AUDIO 2 pour écouter. Le volume commence à 15 %.

Les modulations sont désactivées pour entendre chaque scène de base. Pour les
ajouter : Width CV input=4, Interval CV input=5 et Shape CV input=6. Les trois LFO
bipolaires correspondants tournent à 0,125 / 0,088 / 0,051 Hz. Clock input=None
laisse les scènes autonomes ; Clock input=2 et Clock source=Internal + CV ajoutent
le LFO externe 2,7 Hz en Absolute. Hand Steps attend PULSES 3 après son premier burst.

Le [catalogue JSON](catalog.json) contient les 25 valeurs par voix, les valeurs
communes et tous les paramètres réellement exportés. La source évaluée est
[performance_presets.h](source/performance_presets.h) ; les banques DROID restent
indépendantes. Le [manifeste](manifest.json) donne les empreintes des fichiers.

Les patches enregistrent le chemin absolu de la DLL Windows utilisée lors de
l'export. Si le projet ou la DLL change de dossier, régénérer depuis le projet :

```powershell
python scripts/export-preset-pack.py --library dist/nt_emu/multi_burst.dll
```

Le [guide des 16 scènes](guide.md) décrit leurs intentions et leur rappel sur NT.
